#include <iostream>
using namespace std;
#pragma once
int calcPerimeter(int, int, int);
int calcPlot(int, int);
