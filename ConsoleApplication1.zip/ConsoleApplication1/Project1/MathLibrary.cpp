#include <iostream>
#include "MathLibrary.h"
int calcPerimeter(int a, int b, int c) {
	int sum = 0;
	sum = a + b + c;
	return sum;
}
int calcPlot(int num, int h) {
	int sum = 0; 
	sum = (num * h) / 2;
	return sum;
}