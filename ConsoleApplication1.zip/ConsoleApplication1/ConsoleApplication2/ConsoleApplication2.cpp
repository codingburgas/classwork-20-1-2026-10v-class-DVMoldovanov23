#include <iostream>
#include "../Project1/MathLibrary.h"
int main()
{
    int a, b, c;
    int num, h;
    cin >> a >> b >> c;
    cin >> num >> h;
    cout << calcPerimeter(a, b, c) << endl;
    cout << calcPlot(num, h);
}